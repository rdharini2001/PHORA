#!/usr/bin/env python3
"""AMPLIFAI Codabench entry point — PHORA-Morph v5 QWK-Risk.

Domain-robust morphology Extra-Trees inference with a selective ordinal gate aligned
to quadratic ordinal error. Uses 37 lesion-mask morphology features only. No network,
scikit-learn, SimpleITK, or PyRadiomics is required at inference.
"""
from __future__ import annotations
import os, sys, traceback
from pathlib import Path

os.environ.setdefault('OMP_NUM_THREADS','1')
os.environ.setdefault('OPENBLAS_NUM_THREADS','1')
os.environ.setdefault('MKL_NUM_THREADS','1')
os.environ.setdefault('NUMEXPR_NUM_THREADS','1')

import numpy as np
import pandas as pd

HERE=Path(__file__).resolve().parent
DATA_ROOT=Path(os.environ.get('AMPLIFAI_DATA_ROOT','/app/data/cases'))
MODEL_PATH=HERE/'morph_extra_trees.npz'
VALID_LABELS={'LR-1','LR-2','LR-3','LR-4','LR-5','LR-M','LR-TIV'}
sys.path.insert(0,str(HERE))
from morphology_features import extract_morphology_features, FEATURES
from morph_portable_et import load_model, predict

_MODEL=None

def _init_worker():
    global _MODEL
    _MODEL=load_model(MODEL_PATH)
    if list(_MODEL['features']) != list(FEATURES):
        raise RuntimeError('Model feature list does not match morphology extractor')

def _safe(v):
    try:
        x=float(v); return x if np.isfinite(x) else np.nan
    except Exception:
        return np.nan

def _predict_case(case_id):
    global _MODEL
    if _MODEL is None: _init_worker()
    cid=str(case_id); errors=[]
    try:
        feat=extract_morphology_features(DATA_ROOT/cid,cid,margin_vox=5)
        X=np.asarray([[_safe(feat.get(c,np.nan)) for c in FEATURES]],dtype=np.float32)
    except Exception as exc:
        errors.append(f'features: {type(exc).__name__}: {exc}')
        X=np.full((1,len(FEATURES)),np.nan,dtype=np.float32)
    try:
        pred,p,oc,sc,risk,margin=predict(_MODEL,X)
        label=str(pred[0])
        audit=(f'ord_conf={float(oc[0]):.4f}, special_conf={float(sc[0]):.4f}, '
               f'ord_risk={float(risk[0]):.4f}, ord_margin={float(margin[0]):.4f}')
    except Exception:
        errors.append('model: '+traceback.format_exc(limit=2).replace('\n',' | '))
        label='LR-5'; audit='model_fallback=LR-5'
    if label not in VALID_LABELS:
        errors.append(f'invalid prediction {label!r}; replaced by LR-5'); label='LR-5'
    return cid,label,audit+(' | '+'; '.join(errors) if errors else '')

def _sample_csv(input_arg):
    p=Path(input_arg)
    if p.is_file(): return p
    q=p/'sample_cases.csv'
    if q.exists(): return q
    return Path('/app/input_data/sample_cases.csv')

def main():
    input_arg=sys.argv[1] if len(sys.argv)>1 else '/app/input_data'
    output_arg=sys.argv[2] if len(sys.argv)>2 else '/app/output'
    outdir=Path(output_arg); outdir.mkdir(parents=True,exist_ok=True)
    sample_path=_sample_csv(input_arg); cases=pd.read_csv(sample_path)
    if 'case_id' not in cases.columns: raise ValueError(f'sample_cases.csv must contain case_id: {sample_path}')
    ids=[str(x) for x in cases['case_id'].tolist()]
    print('PHORA-Morph v5 QWK-Risk: '
          f'{len(ids)} cases | 37 morphology features | leaf=5 | tau=0.475 | risk<=1.8 | margin>=0.10 | data={DATA_ROOT}',flush=True)
    requested=int(os.environ.get('PHORA_WORKERS','4'))
    workers=max(1,min(requested,8,len(ids))) if ids else 1
    result_map={}
    if workers==1:
        _init_worker()
        for i,cid in enumerate(ids,1):
            c,p,a=_predict_case(cid); result_map[c]=(p,a)
            print(f'[{i}/{len(ids)}] {c} -> {p} | {a}',flush=True)
    else:
        from concurrent.futures import ProcessPoolExecutor, as_completed
        with ProcessPoolExecutor(max_workers=workers,initializer=_init_worker) as ex:
            fut={ex.submit(_predict_case,cid):cid for cid in ids}; done=0
            for f in as_completed(fut):
                cid=fut[f]; done+=1
                try: c,p,a=f.result()
                except Exception as exc: c=cid; p='LR-5'; a=f'worker failure: {type(exc).__name__}: {exc}'
                result_map[c]=(p,a); print(f'[{done}/{len(ids)}] {c} -> {p} | {a}',flush=True)
    rows=[{'case_id':cid,'prediction':result_map.get(cid,('LR-5','missing worker result'))[0]} for cid in ids]
    out=pd.DataFrame(rows,columns=['case_id','prediction'])
    if len(out)!=len(ids) or out['case_id'].duplicated().any(): raise RuntimeError('Coverage/duplicate error')
    bad=~out['prediction'].isin(VALID_LABELS)
    if bad.any(): raise RuntimeError('Invalid labels generated: '+str(out.loc[bad,'prediction'].unique().tolist()))
    dest=outdir/'predictions.csv'; out.to_csv(dest,index=False)
    print(f'Wrote {dest} ({len(out)} predictions)',flush=True)

if __name__=='__main__': main()
