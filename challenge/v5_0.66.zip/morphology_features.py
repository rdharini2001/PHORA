from __future__ import annotations

"""Inference-only morphology features for PHORA-Morph v3.

The 37 features are copied exactly from the morphology blocks used by the
original PHORA+ v2 feature extractors:
  - 27 ART-grid lesion geometry / topology descriptors
  - 10 native-mask shape descriptors
Only the arterial CT geometry and lesion mask are required. No CT intensity
values are used as predictors.
"""
from pathlib import Path
import math
import numpy as np
from scipy import ndimage
from scipy.spatial import ConvexHull
import nibabel as nib
from nibabel.processing import resample_from_to

EPS = 1e-8

SPATIAL_FEATURES = [
    'geom_voxel_count','geom_volume_mm3','geom_surface_area_mm2','geom_surface_to_volume',
    'geom_equiv_diameter_mm','geom_sphericity','geom_bbox_x_mm','geom_bbox_y_mm','geom_bbox_z_mm',
    'geom_max_bbox_diameter_mm','geom_bbox_volume_mm3','geom_extent','spectral_lambda1','spectral_lambda2',
    'spectral_lambda3','spectral_elongation','spectral_flatness','spectral_anisotropy','geom_radial_mean_mm',
    'geom_radial_std_mm','geom_radial_p90_mm','geom_radial_cv','geom_convex_hull_volume_mm3','geom_solidity',
    'topology_components','topology_cavity_fraction','fractal_box_dimension'
]
SHAPE_FEATURES = [
    'shape_VoxelCount','shape_Volume_mm3','shape_SurfaceArea_mm2','shape_SurfaceVolumeRatio',
    'shape_Sphericity','shape_EquivalentDiameter_mm','shape_MaxBBoxDiameter_mm','shape_BBoxDiagonal_mm',
    'shape_Elongation','shape_Flatness'
]
FEATURES = SPATIAL_FEATURES + SHAPE_FEATURES


def _first_existing(paths):
    for p in paths:
        if p.is_file():
            return p
    return None


def _find_phase(case_dir: Path, case_id: str, phase: str):
    ct = case_dir / 'ct'
    p = _first_existing([ct/f'{case_id}_{phase}.nii.gz', ct/f'{case_id}_{phase}.nii'])
    if p is not None:
        return p
    m = sorted(list(ct.glob(f'*_{phase}.nii.gz')) + list(ct.glob(f'*_{phase}.nii')))
    return m[0] if m else None


def _find_lesion(case_dir: Path):
    ann = case_dir / 'annotations'
    p = _first_existing([ann/'lesion.nii.gz', ann/'lesion.nii'])
    if p is not None:
        return p
    m = sorted(list(ann.glob('*lesion*.nii.gz')) + list(ann.glob('*lesion*.nii')))
    return m[0] if m else None


def _voxel_sizes(affine):
    return np.sqrt((np.asarray(affine, float)[:3,:3] ** 2).sum(axis=0)).astype(float)


def _resample_mask_to(mask_img, target):
    if mask_img.shape[:3] == tuple(target[0]) and np.allclose(mask_img.affine, target[1], atol=1e-4):
        return np.asanyarray(mask_img.dataobj) > 0
    out = resample_from_to(mask_img, target, order=0, mode='constant', cval=0.0)
    return np.asanyarray(out.dataobj) > 0


def _surface_area(mask, spacing):
    m = mask.astype(np.int8)
    padded = np.pad(m, 1, mode='constant', constant_values=0)
    area = 0.0
    for axis in range(3):
        transitions = np.diff(padded, axis=axis) != 0
        face_area = float(np.prod(np.delete(spacing, axis)))
        area += float(np.count_nonzero(transitions)) * face_area
    return area


def _box_count_fractal_dimension(mask):
    shape = np.array(mask.shape)
    max_pow = int(np.floor(np.log2(max(2, int(shape.min())))))
    sizes = [2**k for k in range(max_pow+1) if 2**k <= max(2, int(shape.min()))]
    counts, eps = [], []
    for s in sizes:
        pad = (s - (shape % s)) % s
        pm = np.pad(mask, [(0,int(p)) for p in pad], mode='constant', constant_values=False)
        new_shape = (pm.shape[0]//s,s,pm.shape[1]//s,s,pm.shape[2]//s,s)
        blocks = pm.reshape(new_shape).any(axis=(1,3,5))
        n = int(np.count_nonzero(blocks))
        if n > 0:
            counts.append(n); eps.append(1.0/s)
    if len(counts) < 2:
        return np.nan
    return float(np.polyfit(np.log(eps), np.log(counts), 1)[0])


def _geometry_features(mask, spacing):
    out = {}
    nvox = int(mask.sum())
    voxel_vol = float(np.prod(spacing)); vol = nvox * voxel_vol
    area = _surface_area(mask, spacing) if nvox else np.nan
    idx = np.argwhere(mask)
    out['geom_voxel_count'] = float(nvox)
    out['geom_volume_mm3'] = float(vol)
    out['geom_surface_area_mm2'] = float(area)
    out['geom_surface_to_volume'] = float(area/(vol+EPS)) if nvox else np.nan
    out['geom_equiv_diameter_mm'] = float((6.0*vol/math.pi)**(1/3)) if vol>0 else np.nan
    out['geom_sphericity'] = float((math.pi**(1/3)*(6.0*vol)**(2/3))/(area+EPS)) if vol>0 else np.nan
    if idx.size:
        extents = (idx.max(axis=0)-idx.min(axis=0)+1)*spacing
        out['geom_bbox_x_mm'],out['geom_bbox_y_mm'],out['geom_bbox_z_mm'] = map(float,extents)
        out['geom_max_bbox_diameter_mm'] = float(extents.max())
        out['geom_bbox_volume_mm3'] = float(np.prod(extents))
        out['geom_extent'] = float(vol/(np.prod(extents)+EPS))
        xyz = idx.astype(float)*spacing[None,:]
        centered = xyz-xyz.mean(axis=0,keepdims=True)
        cov = np.cov(centered,rowvar=False) if len(xyz)>3 else np.zeros((3,3))
        eig = np.sort(np.maximum(np.linalg.eigvalsh(cov),0.0))[::-1]
        l1,l2,l3 = (list(eig)+[0.0,0.0,0.0])[:3]
        out['spectral_lambda1']=float(l1); out['spectral_lambda2']=float(l2); out['spectral_lambda3']=float(l3)
        out['spectral_elongation']=float(math.sqrt((l2+EPS)/(l1+EPS)))
        out['spectral_flatness']=float(math.sqrt((l3+EPS)/(l1+EPS)))
        out['spectral_anisotropy']=float((l1-l3)/(l1+EPS))
        r=np.linalg.norm(centered,axis=1)
        if r.size:
            out['geom_radial_mean_mm']=float(np.mean(r)); out['geom_radial_std_mm']=float(np.std(r))
            out['geom_radial_p90_mm']=float(np.percentile(r,90)); out['geom_radial_cv']=float(np.std(r)/(np.mean(r)+EPS))
        boundary=mask & ~ndimage.binary_erosion(mask,structure=ndimage.generate_binary_structure(3,1),border_value=0)
        bidx=np.argwhere(boundary)
        if len(bidx)>=4:
            if len(bidx)>5000:
                sel=np.linspace(0,len(bidx)-1,5000).astype(int); bidx=bidx[sel]
            pts=bidx.astype(float)*spacing[None,:]
            try:
                hull=ConvexHull(pts); out['geom_convex_hull_volume_mm3']=float(hull.volume); out['geom_solidity']=float(vol/(hull.volume+EPS))
            except Exception:
                out['geom_convex_hull_volume_mm3']=np.nan; out['geom_solidity']=np.nan
        else:
            out['geom_convex_hull_volume_mm3']=np.nan; out['geom_solidity']=np.nan
        _,ncc=ndimage.label(mask,structure=ndimage.generate_binary_structure(3,1))
        filled=ndimage.binary_fill_holes(mask); cavity_vox=int(np.count_nonzero(filled & ~mask))
        out['topology_components']=float(ncc); out['topology_cavity_fraction']=float(cavity_vox/(nvox+EPS))
        out['fractal_box_dimension']=_box_count_fractal_dimension(mask)
    return out


def _safe_div(a,b):
    return float(a/b) if np.isfinite(b) and abs(float(b))>1e-12 else np.nan


def _shape_features(mask, spacing_zyx):
    n=int(mask.sum())
    if n==0: return {}
    sp=np.asarray(spacing_zyx,float); voxel_volume=float(np.prod(sp)); volume=n*voxel_volume
    surface=0.0
    for ax in range(3):
        pad=[(0,0)]*3; pad[ax]=(1,1)
        transitions=np.abs(np.diff(np.pad(mask.astype(np.int8),pad,mode='constant'),axis=ax)).sum()
        surface += float(transitions)*float(np.prod(np.delete(sp,ax)))
    coords=np.argwhere(mask).astype(float)*sp[None,:]
    ext=coords.max(0)-coords.min(0)+sp
    eq_d=(6.0*volume/np.pi)**(1/3)
    sphericity=(np.pi**(1/3)*(6.0*volume)**(2/3)/surface) if surface>0 else np.nan
    if n>=4:
        eig=np.sort(np.linalg.eigvalsh(np.cov(coords,rowvar=False)))[::-1]
        elongation=np.sqrt(eig[1]/eig[0]) if eig[0]>0 and eig[1]>=0 else np.nan
        flatness=np.sqrt(eig[2]/eig[0]) if eig[0]>0 and eig[2]>=0 else np.nan
    else:
        elongation=flatness=np.nan
    return {
        'shape_VoxelCount':n,'shape_Volume_mm3':volume,'shape_SurfaceArea_mm2':surface,
        'shape_SurfaceVolumeRatio':_safe_div(surface,volume),'shape_Sphericity':float(sphericity),
        'shape_EquivalentDiameter_mm':float(eq_d),'shape_MaxBBoxDiameter_mm':float(np.max(ext)),
        'shape_BBoxDiagonal_mm':float(np.linalg.norm(ext)),'shape_Elongation':float(elongation),'shape_Flatness':float(flatness)
    }


def extract_morphology_features(case_dir, case_id=None, margin_vox=5):
    case_dir=Path(case_dir); case_id=str(case_id or case_dir.name)
    art_path=_find_phase(case_dir,case_id,'ART'); lesion_path=_find_lesion(case_dir)
    if art_path is None: raise FileNotFoundError(f'Missing ART phase for {case_id}')
    if lesion_path is None: raise FileNotFoundError(f'Missing lesion mask for {case_id}')
    art=nib.load(str(art_path)); lesion=nib.load(str(lesion_path))
    lesion_art=_resample_mask_to(lesion,(art.shape[:3],art.affine))
    idx=np.argwhere(lesion_art)
    if idx.size==0: raise ValueError(f'Empty lesion after ART alignment for {case_id}')
    lo=np.maximum(idx.min(axis=0)-int(margin_vox),0)
    hi=np.minimum(idx.max(axis=0)+int(margin_vox)+1,np.array(art.shape[:3]))
    crop=tuple(slice(int(a),int(b)) for a,b in zip(lo,hi))
    mask=lesion_art[crop].astype(bool)
    spacing=_voxel_sizes(art.affine)
    out={'case_id':case_id}; out.update(_geometry_features(mask,spacing))
    native=(np.asarray(lesion.dataobj)>0).transpose(2,1,0)
    spacing_xyz=_voxel_sizes(lesion.affine)
    out.update(_shape_features(native,tuple(spacing_xyz[::-1])))
    return out
