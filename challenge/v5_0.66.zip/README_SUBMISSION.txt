PHORA-Morph v5 QWK-Risk — AMPLIFAI Codabench submission

Root entry: run.py
Metadata command: python3 /app/ingested_program/run.py $input $output

Model: 1000-tree Extra Trees on 37 lesion-mask morphology features.
Regularization: max_features=0.7, min_samples_leaf=5.
Ordinal policy: tau=0.475, conditional quadratic ordinal risk <= 1.8,
conditional ordinal top-2 margin >= 0.10, and ordinal confidence >= special confidence.
Otherwise predict the better-supported special category (LR-M or LR-TIV).
Fit: 520 public labeled cases available in the supplied PHORA development artifacts.
Portable inference: no sklearn required.
Model SHA256: 2bdc5c0411944b85732db2387e4590e3d1acd9527841bbec7eb838dcb0621949

This package is a development candidate. Private leaderboard score is unknown until evaluated.
