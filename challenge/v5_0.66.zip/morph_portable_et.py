from __future__ import annotations
import json
from pathlib import Path
import numpy as np

ORDINAL_LABELS=['LR-1','LR-2','LR-3','LR-4','LR-5']
SPECIAL_LABELS=['LR-M','LR-TIV']

def load_model(path):
    path=Path(path); z=np.load(path,allow_pickle=False)
    meta=json.loads(path.with_name('morph_extra_trees_meta.json').read_text(encoding='utf-8'))
    offsets=np.asarray(z['tree_offsets'],dtype=np.int64)
    cl=np.asarray(z['children_left'],dtype=np.int32); cr=np.asarray(z['children_right'],dtype=np.int32)
    ff=np.asarray(z['feature'],dtype=np.int32); th=np.asarray(z['threshold'],dtype=np.float32)
    pr=np.asarray(z['proba'],dtype=np.float32)
    trees=[]
    for i in range(len(offsets)-1):
        a,b=int(offsets[i]),int(offsets[i+1])
        trees.append({'children_left':cl[a:b],'children_right':cr[a:b],'feature':ff[a:b],
                      'threshold':th[a:b],'proba':pr[a:b]})
    meta['medians']=np.asarray(z['medians'],dtype=np.float32); meta['trees']=trees
    return meta

def transform(model,X):
    X=np.asarray(X,dtype=np.float32); miss=~np.isfinite(X); X=X.copy()
    med=np.asarray(model['medians'],dtype=np.float32)
    X[miss]=np.broadcast_to(med,X.shape)[miss]
    return X

def predict_proba(model,X):
    X=transform(model,X); n=len(X); k=len(model['labels'])
    out=np.zeros((n,k),dtype=np.float64)
    for tr in model['trees']:
        nodes=np.zeros(n,dtype=np.int32); active=np.ones(n,dtype=bool)
        while active.any():
            idx=np.where(active)[0]; node=nodes[idx]; left=tr['children_left'][node]; leaf=left<0
            if leaf.any(): active[idx[leaf]]=False
            idx2=idx[~leaf]
            if idx2.size:
                node2=nodes[idx2]; feat=tr['feature'][node2]; thr=tr['threshold'][node2]
                go_left=X[idx2,feat] <= thr
                nodes[idx2]=np.where(go_left,tr['children_left'][node2],tr['children_right'][node2])
        out += tr['proba'][nodes]
    out/=max(1,len(model['trees']))
    den=out.sum(axis=1,keepdims=True)
    return np.divide(out,den,out=np.full_like(out,1.0/k),where=den>0)

def predict(model,X):
    p=predict_proba(model,X)
    tau=float(model.get('ordinal_confidence_threshold',0.475))
    risk_thr=float(model.get('ordinal_risk_threshold',1.8))
    margin_thr=float(model.get('ordinal_margin_threshold',0.10))
    ordp=p[:,:5]; spp=p[:,5:7]
    oi=np.argmax(ordp,axis=1); si=np.argmax(spp,axis=1)
    ord_conf=np.max(ordp,axis=1); special_conf=np.max(spp,axis=1)
    ord_sum=ordp.sum(axis=1,keepdims=True)
    cond=np.divide(ordp,ord_sum,out=np.full_like(ordp,0.2),where=ord_sum>0)
    ranks=np.arange(1,6,dtype=np.float64)
    pred_rank=(oi+1).astype(np.float64)
    ordinal_risk=np.sum(((ranks[None,:]-pred_rank[:,None])**2)*cond,axis=1)
    sorted_cond=np.sort(cond,axis=1)
    ordinal_margin=sorted_cond[:,-1]-sorted_cond[:,-2]
    use_ordinal=(ord_conf>=tau)&(ord_conf>=special_conf)&(ordinal_risk<=risk_thr)&(ordinal_margin>=margin_thr)
    labels=np.asarray(model['labels'],dtype=object)
    pred=labels[5+si].copy(); pred[use_ordinal]=labels[oi[use_ordinal]]
    return pred,p,ord_conf,special_conf,ordinal_risk,ordinal_margin
